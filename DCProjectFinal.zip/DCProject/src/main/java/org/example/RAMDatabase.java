package org.example;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RAMDatabase {

    // JDBC URL, username, and password of PostgreSQL server
    private static final String url = "jdbc:postgresql://localhost:5432/postgres";
    private static final String user = "postgres";
    private static final String password = "DCproject123";

    // JDBC variables for opening, closing and querying from the database
    private static Connection connection;
    private static Statement statement;
    private static double score;
    private static double time;
    private static String deviceName;

    public static void InsertTestResultsIntoDatabase  (double score, double time,String device_name) throws SQLException{
        RAMDatabase.score = score;
        RAMDatabase.time = time;
        deviceName = device_name;
        try {
            // Establish connection to the database
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();

            // Generate random data and insert into the animals table
            Random random = new Random();
            int id = random.nextInt(1000);
            InsertTestResultsIntoDatabase(id, score, time, device_name);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the statement and connection
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void InsertTestResultsIntoDatabase(int id, double score, double time, String device_name) throws SQLException {

        String sql = "INSERT INTO ram(test_id, ram_score, time, device_name) VALUES (?,?,?,?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setDouble(2,  score);

            pstmt.setDouble(3,time);
            pstmt.setString(4,device_name);

            pstmt.executeUpdate();
        }

    }
    public static List<RAMtest> getRAMTestResults() throws SQLException {
        String querySQL = "SELECT test_id,ram_score,time,device_name FROM ram";
        List<RAMtest> testsList = new ArrayList<>();

        try {
            // Establish connection to the database
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();

            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                int id = rs.getInt("test_id");
                double time= rs.getDouble("time");
                double score= rs.getDouble("ram_score");
                String device_name = rs.getString("device_name");
                RAMtest test = new RAMtest(id,score,time,device_name);
                testsList.add(test);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return testsList;
    }
}